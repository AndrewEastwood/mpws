
    $customer['DATATABLE'] = array();

    $customer['DATATABLE']['SALE'] = array(
        'TABLE' => 'writer_sale',
        'PAGEKEY' => 'pg',
        'SORTKEY' => 'sort',
        'SEARCH_KEY_PREFIX' => 'searchbox_sale_',
        'LIMIT' => '40',
        'SIZE' => '3',
        'EDGES' => 'FIRST-PREV-NEXT-LAST'
    );