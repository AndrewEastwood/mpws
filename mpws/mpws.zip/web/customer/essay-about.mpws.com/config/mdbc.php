    $customer['MDBC'] = array();
    $customer['MDBC']['DB_USERNAME'] = 'root';
    $customer['MDBC']['DB_PASSWORD'] = '1111';
    $customer['MDBC']['DB_NAME'] = 'mpws_light';
    $customer['MDBC']['DB_DATE_FORMAT'] = 'Y-m-d H:i:s';
