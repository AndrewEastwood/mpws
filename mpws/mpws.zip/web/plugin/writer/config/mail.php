
    $customer['MAIL'] = array();
    
    /* SEND EMAIL ON ACTION WITH TOOLBOX MODE ONLY */
    /* IS NOT IMPLEMENTED */
    $customer['MAIL']['ACTION_TRIGGERS'] = array();