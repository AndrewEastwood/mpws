
    $plugin['GENERAL'] = array();

    $plugin['GENERAL']['NAME'] = 'Writer';
    $plugin['GENERAL']['TITLE'] = 'Writer';
    $plugin['GENERAL']['MENU'] = array(
        'orders.html' => 'Orders',
        'messages.html' => 'Messages',
        'writers.html' => 'Writers',
        'users.html' => 'Users',
        'page-editor.html' => 'Page Editor',
        'balancer.html' => 'Balancer'
    );
