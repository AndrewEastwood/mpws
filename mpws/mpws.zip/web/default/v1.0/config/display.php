
    $default['DISPLAY'] = array();

    $default['DISPLAY']['NAME'] = 'mpws default';

    $default['DISPLAY']['TITLE'] = 'mpws web site';

    $default['DISPLAY']['MENU'] = Array(
        'NORMAL' => array(),
        'SEO' => array(
            'short' => Array(
                '_TITLE_' => ''
            )
        )
    );

    // TREE, LIST
    //$default['DISPLAY']['CATEGORY_STYLE'] = 'TREE';
    // FULL, SMART
    //$default['DISPLAY']['STRUCTURE_STYLE'] = 'SMART';

    $default['DISPLAY']['SESSION_TIME'] = 10;
    //
    $default['DISPLAY']['MENU_TYPE'] = 'SEO';

    $default['DISPLAY']['KEYWORDS'] = '';

    $default['DISPLAY']['DESCRIPTION'] = '';
    //
    $default['DISPLAY']['DESCRIPTION_2'] = '';
    //
    $default['DISPLAY']['PAGE_TITLES'] = array();
