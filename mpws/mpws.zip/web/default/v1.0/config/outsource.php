

    $default['OUTSOURCE'] = array();

    // domain => search map

    $default['OUTSOURCE']['DOMAINS'] = array();

    // fetch useful part of data
    $default['OUTSOURCE']['CLEANER'] = array();
