    $default['MDBC'] = array();
    $default['MDBC']['DB_HOST'] = 'localhost';
    $default['MDBC']['DB_USERNAME'] = '';
    $default['MDBC']['DB_PASSWORD'] = '';
    $default['MDBC']['DB_NAME'] = 'mpws_default';
    $default['MDBC']['DB_CHARSET'] = 'utf8';
