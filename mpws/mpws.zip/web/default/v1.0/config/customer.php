

    $default['CUSTOMER'] = array();

    // define library the will be included
    // with custom mathods.
    // the name should be in the next format:
    // md5($customerName) + '.php'
    // it must be stored in the root customer's directory'
    $default['INTERNAL_LIBRARY'] = '';



