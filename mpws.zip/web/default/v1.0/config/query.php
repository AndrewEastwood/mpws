

    $default['QUERY'] = array();
