

    $default['SEO'] = array();
    
    $default['SEO']['SEOLINKS'] = true;
    
    $default['SEO']['MAP'] = array(
        'aid' => 'product',
        'cid' => 'category',
        'oid' => 'origin'
    );
    
    $default['SEO']['GOOGLE_ANALYTICS_ACCOUT'] = 'UA-18549331-1';

