
    $customer['MAIL'] = array();

    $customer['MAIL']['URLS'] = array(
        'LOGIN' => 'http://' . $_SERVER['SERVER_NAME'] . '/page/login.html',
        'ACTIVATE' => 'http://' . $_SERVER['SERVER_NAME'] . '/page/activate.html?digest='
    );
