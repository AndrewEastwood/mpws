    $customer['QUERY'] = array();
    
    $customer['QUERY']['GET_ORDER_FIELDS'] = 'SHOW COLUMNS FROM writer_orders;';
    