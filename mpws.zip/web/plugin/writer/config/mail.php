
    $customer['MAIL'] = array();
    $customer['MAIL']['ACTION_TRIGGERS'] = array(
        'ON_NEW_ORDER' => $default['MAIL']['SUPPORT']
    );