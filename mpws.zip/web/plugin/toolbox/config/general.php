
    $plugin['GENERAL'] = array();

    $plugin['GENERAL']['NAME'] = 'Toolbox';
    $plugin['GENERAL']['TITLE'] = 'Toolbox';
    $plugin['GENERAL']['MENU'] = array(
        'index.html' => 'Services',
        'users.html' => 'Users',
        'exit.html' => 'Exit'
    );
